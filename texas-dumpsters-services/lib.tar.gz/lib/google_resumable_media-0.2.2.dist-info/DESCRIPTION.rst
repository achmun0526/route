``google-resumable-media``
==========================

    Utilities for Google Media Downloads and Resumable Uploads

|circleci|

See the `docs`_ for examples and usage.

.. _docs: https://googlecloudplatform.github.io/google-resumable-media-python/latest/

License
-------

Apache 2.0 - See `the LICENSE`_ for more information.

.. _the LICENSE: https://github.com/GoogleCloudPlatform/google-resumable-media-python/blob/master/LICENSE

.. |circleci| image:: https://circleci.com/gh/GoogleCloudPlatform/google-resumable-media-python.svg?style=shield
   :target: https://circleci.com/gh/GoogleCloudPlatform/google-resumable-media-python


